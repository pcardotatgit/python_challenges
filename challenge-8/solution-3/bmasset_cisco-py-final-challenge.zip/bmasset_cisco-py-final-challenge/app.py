from flask import Flask
from flask import render_template
from socket import gethostname
from getpass import getuser
import socket
import requests
import sqlite3

app = Flask(__name__)

def create_table_liste(conn):
    """ create a table named Liste
    :param conn: Connection object
    :param create_table_sql: a CREATE TABLE statement
    :return:
    """
    create_table_sql = """ CREATE TABLE IF NOT EXISTS Liste (
                            id integer PRIMARY KEY,
                            title varchar(256),
                            url varchar(256),
                            thumbnailUrl varchar(256)
                            );"""
    try:
        c = conn.cursor()
        c.execute(create_table_sql)
    except sqlite3.Error as e:
        print(e)


def insert_item(conn, item):
    """
    Create a new photo into the liste table
    :param conn:
    :param item:
    :return: project id
    """
    sql = """ INSERT OR REPLACE INTO Liste(id,title,url,thumbnailUrl) VALUES(?,?,?,?); """
    item = [item["id"], item["title"], item["url"], item["thumbnailUrl"]]
    cur = conn.cursor()
    cur.execute(sql, item)
    conn.commit()
    return cur.lastrowid


def get_item_from_liste(conn, id):
    sql = """SELECT * FROM Liste WHERE ID IN (?)"""
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    cur.execute(sql, [id])
    res = cur.fetchone()
    if res is not None:
        item = dict(res)
        return item
    else:
        return None


def get_n_sort_photo_endswith(url, endswith):
    sorted_items = []
    try:
        res_json = requests.get(url).json()
        for item in res_json:
            if item['title'].endswith(endswith):
                sorted_items.append(item)
        return sorted_items
    except requests.ConnectionError as e:
        print(e)
        return None


def actions_db():
    try:
        with sqlite3.connect("db/THE_TABLE.db") as conn:
            create_table_liste(conn)
            res_photos = get_n_sort_photo_endswith('https://jsonplaceholder.typicode.com/photos', 'corporis')
            if res_photos is not None:
                for photo in res_photos:
                    insert_item(conn, photo)
            item_id = ['2878', '3685', '4633']
            item = []
            for i in sorted(item_id):
                item.append(get_item_from_liste(conn, i))
            item = list(filter(None.__ne__, item))
            if item:
                return item
            return None
    except sqlite3.Error as e:
        print(e)
        return None


def collect_user_data():
    global local_ip_address, geoloc, data, connectivity
    connectivity = False
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 1))
        local_ip_address = s.getsockname()[0]
        connectivity = True
        try:
            geoloc = requests.get("http://ip-api.com/json").json()
            data = {'username': getuser(), 'hostname': gethostname(), 'privIP': local_ip_address, 'pubIP': geoloc["query"]}
            return connectivity, data, geoloc
        except requests.exceptions.RequestException as e:
            print("Geoloc collect error :", e)
            data = {'username': getuser(), 'hostname': gethostname()}
            return connectivity, data, None
    except socket.error as e:
        print("Collect user data :", e)
        data = {'username': getuser(), 'hostname': gethostname()}
        return connectivity, data, None


@app.route('/')
def serve_index():
    connectivity, user_data, geoloc = collect_user_data()
    wanted_photos = actions_db()
    return render_template('page.html', data=user_data, geoloc=geoloc, wanted_photos=wanted_photos)


if __name__ == '__main__':
    app.run(port=8080)

