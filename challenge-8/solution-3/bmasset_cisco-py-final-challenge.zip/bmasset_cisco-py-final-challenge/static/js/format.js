var util = util || {};
util.toArray = function(list) {
    return Array.prototype.slice.call(list || [], 0);
};
var Terminal = Terminal || function(cmdLineContainer, outputContainer) {
    window.URL = window.URL || window.webkitURL;
    window.requestFileSystem = window.requestFileSystem || window.webkitRequestFileSystem;

    let cmdLine_ = document.querySelector(cmdLineContainer);
    let output_ = document.querySelector(outputContainer);

    const CMDS_ = [
        'clear', 'clock', 'date', 'echo', 'help', 'uname', 'whoami', 'show'
    ];

    let fs_ = null;
    let cwd_ = null;
    let history_ = [];
    let histpos_ = 0;
    let histtemp_ = 0;

    window.addEventListener('click', function(e) {
        cmdLine_.focus();
    }, false);

    cmdLine_.addEventListener('click', inputTextClick_, false);
    cmdLine_.addEventListener('keydown', historyHandler_, false);
    cmdLine_.addEventListener('keydown', processNewCommand_, false);

    //
    function inputTextClick_(e) {
        this.value = this.value;
    }

    //
    function historyHandler_(e) {
        if (history_.length) {
            if (e.key === "ArrowUp" || e.key === "ArrowDown") {
                if (history_[histpos_]) {
                    history_[histpos_] = this.value;
                } else {
                    histtemp_ = this.value;
                }
            }

            if (e.key === "ArrowUp") { // up
                histpos_--;
                if (histpos_ < 0) {
                    histpos_ = 0;
                }
            } else if (e.key === "ArrowDown") { // down
                histpos_++;
                if (histpos_ > history_.length) {
                    histpos_ = history_.length;
                }
            }

            if (e.key === "ArrowUp" || e.key === "ArrowDown") {
                this.value = history_[histpos_] ? history_[histpos_] : histtemp_;
            }
        }
    }

    //
    function processNewCommand_(e) {

        if (e.key === "Tab") {
            e.preventDefault();
            if(this.value !== "") {
                CMDS_.forEach(_cmd => {
                    if (_cmd.startsWith(this.value)) {
                        this.value = _cmd;
                    }
                });
            }
        } else if (e.key === "Enter") {
            // Save shell history.
            if (this.value) {
                history_[history_.length] = this.value;
                histpos_ = history_.length;
            }

            // Duplicate current input and append to output section.
            let line = this.parentNode.parentNode.cloneNode(true);
            line.removeAttribute('id');
            line.classList.add('line');
            let input = line.querySelector('input.cmdline');
            input.autofocus = false;
            input.readOnly = true;
            output_.appendChild(line);

            if (this.value && this.value.trim()) {
                var args = this.value.split(' ').filter(function(val, i) {
                    return val;
                });
                var cmd = args[0].toLowerCase();
                args = args.splice(1); // Remove cmd from arg list.
            }

            switch (cmd) {
                case 'clear':
                    output_.innerHTML = '';
                    this.value = '';
                    return;
                case 'clock':
                    let appendDiv = jQuery($('.clock-container')[0].outerHTML);
                    appendDiv.attr('style', 'display:inline-block');
                    output_.appendChild(appendDiv[0]);
                    break;
                case 'date':
                    output( new Date() );
                    break;
                case 'echo':
                    output( args.join(' ') );
                    break;
                case 'help':
                    output('<div class="ls-files">' + CMDS_.join('<br>') + '</div>');
                    break;
                case 'uname':
                    output(navigator.appVersion);
                    break;
                case 'whoami':
                    output('<pre id="whoami"></pre>');
                    document.getElementById("whoami").innerHTML = JSON.stringify(data, null, 2);
                    break;
                case 'sh':
                case 'show':
                    let cmd_args = args.join(' ');
                    if (!cmd_args) {
                        output('Usage:</br>' + 'table&emsp;&emsp;Show the result table of this challenge');
                        break;
                    }
                    if (cmd_args === "table"){
                        if(wanted_photos) {
                            output(
                                '<table><tbody id="tbody">' +
                                '<tr><th>ID</th><th>TITLE</th><th>URL (too big to show)</th><th>THUMBNAIL_URL</th></tr>' +
                                '</tbody></table>'
                            );
                            var tbody = document.getElementById("tbody");
                            wanted_photos.forEach(photo => {
                                var new_tr = document.createElement('tr');
                                var new_td_id = document.createElement('td');
                                new_td_id.innerHTML = photo.id;
                                var new_td_title = document.createElement('td');
                                new_td_title.innerHTML = photo.title;
                                var new_td_url = document.createElement('td');
                                new_td_url.innerHTML = photo.url;
                                var new_td_thumbnailUrl = document.createElement('td');
                                if(!navigator.onLine){
                                    new_td_thumbnailUrl.innerHTML = photo.thumbnailUrl;
                                }
                                else {
                                    var new_img = document.createElement('img');
                                    new_img.src = photo.thumbnailUrl;
                                    new_td_thumbnailUrl.appendChild(new_img);
                                }
                                new_tr.appendChild(new_td_id);
                                new_tr.appendChild(new_td_title);
                                new_tr.appendChild(new_td_url);
                                new_tr.appendChild(new_td_thumbnailUrl);
                                tbody.appendChild(new_tr);
                            });
                            tbody.id = "old_tbody";
                        }
                        else {
                            output("Network unreachable, db not loaded. Please check your connection and refresh the page !")
                        }
                    }
                    break;
                default:
                    if (cmd) {
                        output(cmd + ': command not found');
                    }
            }
            window.scrollTo(0, getDocHeight_());
            this.value = ''; // Clear/setup line for next input.
        }
    }

    //
    function formatColumns_(entries) {
        let maxName = entries[0].name;
        util.toArray(entries).forEach(function(entry, i) {
            if (entry.name.length > maxName.length) {
                maxName = entry.name;
            }
        });

        let height = entries.length <= 3 ?
            'height: ' + (entries.length * 15) + 'px;' : '';

        // 12px monospace font yields ~7px screen width.
        let colWidth = maxName.length * 7;

        return ['<div class="ls-files" style="-webkit-column-width:',
            colWidth, 'px;', height, '">'];
    }

    //
    function output(html) {
        output_.insertAdjacentHTML('beforeEnd', '<p>' + html + '</p>');
    }

    // Cross-browser impl to get document's height.
    function getDocHeight_() {
        let d = document;
        return Math.max(
            Math.max(d.body.scrollHeight, d.documentElement.scrollHeight),
            Math.max(d.body.offsetHeight, d.documentElement.offsetHeight),
            Math.max(d.body.clientHeight, d.documentElement.clientHeight)
        );
    }

    return {
        init: function() {
            output(
                '<img align="left" src="/static/img/python.png" width="100" height="100" style="padding: 0px 10px 20px 0px">' +
                '<h2 style="letter-spacing: 4px">CISCO Python Training</h2>' +
                '<p>Final challenge, by pcardot.</p>' +
                '<p>' + new Date() + '</p>' +
                '</br>' +
                '<p class="welcome">Welcome '+data.username+' !</p>' +
                '<pre id="json"></pre><p>Enter "help" for more information.</p>'
            );
            if (geoloc) {
                let geoloc_dict = {
                    "ip": geoloc.query,
                    "as": geoloc.as,
                    "isp": geoloc.isp,
                    "longitude": geoloc.lon,
                    "latitude": geoloc.lat,
                    "zip": geoloc.zip,
                    "city": geoloc.city,
                    "district": geoloc.district,
                    "region": geoloc.region,
                    "country_name": geoloc.country,
                    "city": geoloc.city
                };
                document.getElementById("json").innerHTML = "collected_infos "+JSON.stringify(geoloc_dict, null, 2);
            }
        },
        output: output
    }
};

